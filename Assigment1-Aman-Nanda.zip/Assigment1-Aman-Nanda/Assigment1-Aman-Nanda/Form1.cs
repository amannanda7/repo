﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assigment1_Aman_Nanda
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void avggrd_Click(object sender, EventArgs e)
        {
            // declare variables

             decimal html = Convert.ToDecimal(htmltxt.Text);
            decimal css = Convert.ToDecimal(csstxt.Text);
            decimal php = Convert.ToDecimal(phptxt.Text);
            decimal java = Convert.ToDecimal(javatxt.Text);
            decimal c = Convert.ToDecimal(ctxt.Text);
            decimal ruby = Convert.ToDecimal(rubytxt.Text);
            decimal avggrade;
            decimal totalgrade;
            string lettergrade = null;


            // calculate avg grade
            // sum of all subjects divided by number of subjects
            totalgrade = (html + css + php + css + java + ruby);
            avggrade = totalgrade / 6;

            if (avggrade >= 0 && avggrade < 100)
            {
                avggrade = Convert.ToDecimal(string.Format("{0:0,00}", avggrade));

            }
            avggrdtxtbox.Text = avggrade.ToString(avggrade + "%");



            // if statement for csstxtbox

            if (css >= 80 && css > 100)
            {
                lettergrade = "A";
            }
            else if (css >= 70 && css > 79)
            {
                lettergrade = "B";
            }
            else if (css >= 60 && css < 69)
            {
                lettergrade = "C";
            }
            else if (css >= 50 && css < 59)
            {
                lettergrade = "D";
            }
            else if (css >= 0 && css < 49)
            {
                lettergrade = "F";
            }

            csslbl1.Text = lettergrade;




            // if statement for phptxtbox

            if (php >= 80 && php > 100)
            {
                lettergrade = "A";
            }
            else if (php >= 70 && php > 79)
            {
                lettergrade = "B";
            }
            else if (php >= 60 && php < 69)
            {
                lettergrade = "C";
            }
            else if (php >= 50 && php < 59)
            {
                lettergrade = "D";
            }
            else if (php >= 0 && php < 49)
            {
                lettergrade = "F";
            }

            phplbl1.Text = lettergrade;




            // if statement for ctxtbox

            if (c >= 80 && c > 100)
            {
                lettergrade = "A";
            }
            else if (c >= 70 && c > 79)
            {
                lettergrade = "B";
            }
            else if (c >= 60 && c < 69)
            {
                lettergrade = "C";
            }
            else if (c >= 50 && c < 59)
            {
                lettergrade = "D";
            }
            else if (c >= 0 && c < 49)
            {
                lettergrade = "F";
            }

            clbl1.Text = lettergrade;




            // if statement for htmltxtbox

            if (html >= 80 && html > 100)
            {
                lettergrade = "A";
            }
            else if (html >= 70 && html > 79)
            {
                lettergrade = "B";
            }
            else if (html >= 60 && html < 69)
            {
                lettergrade = "C";
            }
            else if (html >= 50 && html < 59)
            {
                lettergrade = "D";
            }
            else if (html >= 0 && html < 49)
            {
                lettergrade = "F";
            }

            htmllbl1.Text = lettergrade;





            // if statement for rubytxtbox

            if (ruby >= 80 && ruby > 100)
            {
                lettergrade = "A";
            }
            else if (ruby >= 70 && ruby > 79)
            {
                lettergrade = "B";
            }
            else if (ruby >= 60 && ruby < 69)
            {
                lettergrade = "C";
            }
            else if (ruby >= 50 && ruby < 59)
            {
                lettergrade = "D";
            }
            else if (ruby >= 0 && ruby < 49)
            {
                lettergrade = "F";
            }

            rubylbl1.Text = lettergrade;





            // if statement for javatxtbox

            if (java >= 80 && java > 100)
            {
                lettergrade = "A";
            }
            else if (java >= 70 && java > 79)
            {
                lettergrade = "B";
            }
            else if (java >= 60 && java < 69)
            {
                lettergrade = "C";
            }
            else if (java >= 50 && java < 59)
            {
                lettergrade = "D";
            }
            else if (java >= 0 && java < 49)
            {
                lettergrade = "F";
            }

            javalbl1.Text = lettergrade;




            // if statement for avggradetxtbox

            if (avggrade >= 80 && avggrade > 100)
            {
                lettergrade = "A";
            }
            else if (avggrade >= 70 && avggrade > 79)
            {
                lettergrade = "B";
            }
            else if (avggrade >= 60 && avggrade < 69)
            {
                lettergrade = "C";
            }
            else if (avggrade >= 50 && avggrade < 59)
            {
                lettergrade = "D";
            }
            else if (avggrade >= 0 && avggrade < 49)
            {
                lettergrade = "F";
            }

            avggrdlbl1.Text = lettergrade;


           













        }
    }
}
